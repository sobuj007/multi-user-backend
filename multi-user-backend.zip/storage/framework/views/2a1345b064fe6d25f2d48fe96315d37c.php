<?php $__env->startSection('content'); ?>
<div class="container mx-auto p-4">
    <h1 class="text-2xl font-bold mb-6">Edit Expert</h1>

    <form action="<?php echo e(route('experts.update', $expert->id)); ?>" method="POST" enctype="multipart/form-data" class="space-y-6">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PATCH'); ?>

        <div class="mb-4">
            <label for="name" class="block text-sm font-medium text-gray-700">Name</label>
            <input type="text" name="name" value="<?php echo e($expert->name); ?>" class="mt-1 block w-full p-2 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" required>
        </div>

        <div class="mb-4">
            <label for="gender" class="block text-sm font-medium text-gray-700">Gender</label>
            <select name="gender" class="mt-1 block w-full p-2 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                <option value="male" <?php echo e($expert->gender == 'male' ? 'selected' : ''); ?>>Male</option>
                <option value="female" <?php echo e($expert->gender == 'female' ? 'selected' : ''); ?>>Female</option>
                <option value="other" <?php echo e($expert->gender == 'other' ? 'selected' : ''); ?>>Other</option>
            </select>
        </div>

        <div class="mb-4">
            <label for="image" class="block text-sm font-medium text-gray-700">Profile Image</label>
            <input type="file" name="image" class="mt-1 block w-full p-2 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
            <?php if($expert->image): ?>
                <img src="<?php echo e(asset('storage/' . $expert->image)); ?>" class="mt-2 w-32 h-32 object-cover rounded">
            <?php endif; ?>
        </div>

        <div class="mb-4">
            <label for="expertise" class="block text-sm font-medium text-gray-700">Expertise</label>
            <input type="text" name="expertise" value="<?php echo e($expert->expertise); ?>" class="mt-1 block w-full p-2 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" required>
        </div>

        <div class="mb-4">
            <label for="certificate_name" class="block text-sm font-medium text-gray-700">Certificate Name</label>
            <input type="text" name="certificate_name" value="<?php echo e($expert->certificate_name); ?>" class="mt-1 block w-full p-2 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" required>
        </div>

        <div class="mb-4">
            <label for="certificate_images" class="block text-sm font-medium text-gray-700">Upload Certificate Images (optional)</label>
            <input type="file" name="certificate_images[]" class="mt-1 block w-full p-2 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" multiple>
            <?php if($expert->certificate_images): ?>
                <?php $__currentLoopData = json_decode($expert->certificate_images, true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <img src="<?php echo e(asset('storage/' . $image)); ?>" class="mt-2 w-32 h-32 object-cover rounded">
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>

        <div class="mb-4">
            <label for="experience_year" class="block text-sm font-medium text-gray-700">Experience Year</label>
            <input type="number" name="experience_year" value="<?php echo e($expert->experience_year); ?>" class="mt-1 block w-full p-2 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" required>
        </div>

        <button type="submit" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
            Update Expert
        </button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\multi-user-backend\resources\views/experts/edit.blade.php ENDPATH**/ ?>