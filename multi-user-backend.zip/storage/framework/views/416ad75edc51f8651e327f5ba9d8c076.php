<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-4 py-6">
    <h1 class="text-2xl font-semibold mb-4">Body Parts</h1>
    <a href="<?php echo e(route('bodyparts.create')); ?>" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">Add Body Part</a>
    <div class="mt-6 overflow-x-auto">
        <table class="min-w-full bg-white border border-gray-200 rounded-lg shadow-md">
            <thead class="bg-gray-100 border-b border-gray-200">
                <tr>
                    <th class="px-6 py-3 text-left text-gray-500">ID</th>
                    <th class="px-6 py-3 text-left text-gray-500">Subcategory</th>
                    <th class="px-6 py-3 text-left text-gray-500">Name</th>
                    <th class="px-6 py-3 text-left text-gray-500">Image</th>
                    <th class="px-6 py-3 text-left text-gray-500">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $bodyparts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bodypart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="border-b border-gray-200">
                    <td class="px-6 py-4 text-gray-700"><?php echo e($bodypart->id); ?></td>
                    <td class="px-6 py-4 text-gray-700"><?php echo e($bodypart->subcategory->subcategory_name); ?></td>
                    <td class="px-6 py-4 text-gray-700"><?php echo e($bodypart->bodypart_name); ?></td>
                    <td class="px-6 py-4 text-gray-700">
                        <?php if($bodypart->image): ?>
                            <img src="<?php echo e(Storage::url($bodypart->image)); ?>" class="w-24 h-24 object-cover rounded" alt="Body Part Image">
                        <?php endif; ?>
                    </td>
                    <td class="px-6 py-4 text-gray-700 flex space-x-2">
                        <a href="<?php echo e(route('bodyparts.edit', $bodypart->id)); ?>" class="bg-yellow-500 text-white px-2 py-1 rounded hover:bg-yellow-600">Edit</a>
                        <form action="<?php echo e(route('bodyparts.destroy', $bodypart->id)); ?>" method="POST" class="inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="bg-red-500 text-white px-2 py-1 rounded hover:bg-red-600">Delete</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\multi-user-backend\resources\views/bodyparts/index.blade.php ENDPATH**/ ?>