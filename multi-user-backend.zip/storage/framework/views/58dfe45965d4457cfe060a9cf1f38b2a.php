<?php $__env->startSection('content'); ?>
<div class="container mx-auto p-4">
    <h1 class="text-2xl font-bold mb-6">Service Images</h1>

    <?php if(session('success')): ?>
    <div id="success-message" class="bg-green-500 text-white p-2 mb-4">
        <?php echo e(session('success')); ?>

    </div>
    <?php endif; ?>

    <a href="<?php echo e(route('service_images.create')); ?>" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">Add Service Image</a>

    <table class="min-w-full bg-white mt-4">
        <thead>
            <tr>
                <th class="py-2">ID</th>
                <th class="py-2">Title</th>
                <th class="py-2">Description</th>
                <th class="py-2">Images</th>
                <th class="py-2">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $serviceImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $serviceImage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td class="py-2"><?php echo e($serviceImage->id); ?></td>
                <td class="py-2"><?php echo e($serviceImage->title); ?></td>
                <td class="py-2"><?php echo e($serviceImage->description); ?></td>
                <td class="py-2">
                    <?php $__currentLoopData = $serviceImage->files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <img src="<?php echo e(asset('storage/' . $file->path)); ?>" alt="<?php echo e($serviceImage->title); ?>" width="100">
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
                <td class="py-2">
                    <a href="<?php echo e(route('service_images.edit', $serviceImage->id)); ?>" class="bg-yellow-500 hover:bg-yellow-700 text-white font-bold py-1 px-2 rounded">Edit</a>
                    <form action="<?php echo e(route('service_images.destroy', $serviceImage->id)); ?>" method="POST" class="inline">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="bg-red-500 hover:bg-red-700 text-white font-bold py-1 px-2 rounded">Delete</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function() {
        setTimeout(function() {
            $('#success-message').fadeOut('slow');
        }, 2000);
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\multi-user-backend\resources\views/service_images/index.blade.php ENDPATH**/ ?>