<nav class="h-full">
    <ul class="list-group py-5 px-6 ">

        <?php if(Auth::user()->role==='admin'): ?>
        <li calss="<?php echo e(request()->is('/admin*') ? 'text-white-500' : 'text-gray-700'); ?> list-group-item  text-orange-500 " ><a class="text-neutral-50 block" href="<?php echo e(Route('admin.dashboard')); ?>">Home</a></li>
        

        <?php endif; ?>
        <?php if(Auth::user()->role==='agent'): ?>
            <li calss="<?php echo e(request()->is('*agent*') ? 'text-blue-500' : 'text-gray-700'); ?> list-group-item py-2  active:text-white-600 " ><a href="<?php echo e(Route('agent.dashboard')); ?>">Home</a></li>
            <li class="list-group-item py-2 <?php echo e(request()->is('agent/dashboard*') ? 'active' : ''); ?> active:bg-blue-600 " ><a href="">My Tasks</a></li>

        <?php endif; ?>
    </ul>
</nav>
<?php /**PATH D:\laragon\www\multi-user-backend\resources\views/profile/partials/sidebar.blade.php ENDPATH**/ ?>