<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-4 py-6">
    <h1 class="text-2xl font-semibold mb-4">Create Body Part</h1>
    <form action="<?php echo e(route('bodyparts.store')); ?>" method="POST" enctype="multipart/form-data" class="bg-white p-6 rounded-lg shadow-md">
        <?php echo csrf_field(); ?>
        <div class="mb-4">
            <label for="subcategory_id" class="block text-gray-700 text-sm font-medium mb-2">Subcategory</label>
            <select name="subcategory_id" id="subcategory_id" class="form-select block w-full mt-1 border-gray-300 rounded-md shadow-sm" required>
                <option value="">Select a subcategory</option>
                <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($subcategory->id); ?>"><?php echo e($subcategory->subcategory_name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="mb-4">
            <label for="bodypart_name" class="block text-gray-700 text-sm font-medium mb-2">Name</label>
            <input type="text" name="bodypart_name" id="bodypart_name" class="form-input block w-full mt-1 border-gray-300 rounded-md shadow-sm" value="<?php echo e(old('bodypart_name')); ?>" required>
        </div>

        <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">Save</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\multi-user-backend\resources\views/bodyparts/create.blade.php ENDPATH**/ ?>