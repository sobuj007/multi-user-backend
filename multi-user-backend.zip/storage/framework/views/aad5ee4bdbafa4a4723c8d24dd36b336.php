<?php $__env->startSection('content'); ?>
<div class="container mx-auto p-4">
    <h1 class="text-2xl font-bold mb-6">Service Images</h1>

    <a href="<?php echo e(route('service_images.create')); ?>" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">Add Service Image</a>

    <?php if(session('success')): ?>
        <div class="bg-green-500 text-white p-2 mt-4">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <table class="min-w-full bg-white mt-4 border border-gray-300">
        <thead>
            <tr>
                <th class="py-2 px-4 border-b">ID</th>
                <th class="py-2 px-4 border-b">Title</th>
                <th class="py-2 px-4 border-b">Description</th>
                <th class="py-2 px-4 border-b">Images</th>
                <th class="py-2 px-4 border-b">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $servicesImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servicesImage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="py-2 px-4 border-b"><?php echo e($servicesImage->id); ?></td>
                    <td class="py-2 px-4 border-b"><?php echo e($servicesImage->title); ?></td>
                    <td class="py-2 px-4 border-b"><?php echo e($servicesImage->description); ?></td>
                    <td class="py-2 px-4 border-b">
                        <?php $__currentLoopData = $servicesImage->files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <img src="<?php echo e(asset('storage/' . $file->path)); ?>" alt="<?php echo e($servicesImage->title); ?>" class="w-32 h-32 object-cover rounded">
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                    <td class="py-2 px-4 border-b">
                        <a href="<?php echo e(route('service_images.edit', $servicesImage->id)); ?>" class="bg-yellow-500 hover:bg-yellow-700 text-white font-bold py-1 px-2 rounded">Edit</a>
                        <form action="<?php echo e(route('service_images.destroy', $servicesImage->id)); ?>" method="POST" class="inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="bg-red-500 hover:bg-red-700 text-white font-bold py-1 px-2 rounded">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\multi-user-backend\resources\views/services_images/index.blade.php ENDPATH**/ ?>